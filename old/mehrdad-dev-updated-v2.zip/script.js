(() => {
  'use strict';

  const CONFIG = {
    githubUser: 'mehrdadmb2',
    featuredProjects: 6,
    featuredSites: 3,
    cacheKey: 'mehrdad-dev.github.v4',
    cacheTTL: 15 * 60 * 1000,
    requestTimeout: 10000,
    repoPageSize: 100,
    maxRepoPages: 3
  };

  const state = {
    repos: [],
    sites: [],
    filteredRepos: [],
    filteredSites: [],
    allProjectsOpen: false,
    allSitesOpen: false,
    reducedMotion: window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const escapeHTML = value => String(value ?? '').replace(/[&<>'"]/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[ch]));
  const formatNumber = value => new Intl.NumberFormat('en-US').format(Number(value || 0));
  const relativeDate = date => {
    if (!date) return 'unknown';
    const diff = Date.now() - new Date(date).getTime();
    const days = Math.floor(diff / 86400000);
    if (days <= 0) return 'today';
    if (days === 1) return '1d ago';
    if (days < 30) return `${days}d ago`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months}mo ago`;
    return `${Math.floor(months / 12)}y ago`;
  };

  function showToast(message, type = 'success') {
    const container = $('#toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check'}"></i><span>${escapeHTML(message)}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3200);
  }

  async function fetchJSON(url, { timeout = CONFIG.requestTimeout, retries = 2 } = {}) {
    for (let attempt = 0; attempt <= retries; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeout);
      try {
        const res = await fetch(url, {
          signal: controller.signal,
          headers: { Accept: 'application/vnd.github+json' },
          cache: 'no-store'
        });
        clearTimeout(timer);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
      } catch (error) {
        clearTimeout(timer);
        if (attempt === retries) throw error;
        await sleep(350 * (attempt + 1));
      }
    }
    throw new Error('Request failed');
  }

  // ---------------- LOADER / MATRIX ----------------
  function initMatrixLoader() {
    const loader = $('#loader');
    const canvas = $('#matrix-canvas');
    const bar = $('#loader-progress-bar');
    const status = $('#loader-status');
    if (!loader || !canvas) return;

    document.body.classList.add('loading');
    const ctx = canvas.getContext('2d');
    let width = 0, height = 0, columns = [], raf = 0, started = false;
    const chars = 'アァカサタナハマヤラワガザダバパ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<>[]{}#@$%&'.split('');

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      width = canvas.clientWidth = window.innerWidth;
      height = canvas.clientHeight = window.innerHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const size = 15;
      columns = new Array(Math.ceil(width / size)).fill(0).map(() => Math.random() * height / size);
    }

    function draw() {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.08)';
      ctx.fillRect(0, 0, width, height);
      ctx.font = '14px Share Tech Mono, monospace';
      columns.forEach((y, i) => {
        const char = chars[Math.floor(Math.random() * chars.length)];
        const x = i * 15;
        const bright = Math.random() > 0.88;
        ctx.fillStyle = bright ? '#d1ffea' : '#18d26a';
        ctx.shadowBlur = bright ? 10 : 3;
        ctx.shadowColor = '#18d26a';
        ctx.fillText(char, x, y * 15);
        ctx.shadowBlur = 0;
        if (y * 15 > height && Math.random() > 0.975) columns[i] = 0;
        else columns[i] += 0.45;
      });
      raf = requestAnimationFrame(draw);
    }

    resize();
    window.addEventListener('resize', resize, { passive: true });
    if (!state.reducedMotion) draw();
    else { ctx.fillStyle = '#04130a'; ctx.fillRect(0, 0, width, height); }

    const messages = [
      'Loading Japanese glyph matrix…',
      'Booting visual systems…',
      'Opening GitHub channel…',
      'Preparing interactive layer…',
      'Portfolio ready.'
    ];
    let progress = 0;
    let index = 0;
    const timer = setInterval(() => {
      progress = Math.min(100, progress + 20);
      if (bar) bar.style.width = `${progress}%`;
      if (status) status.textContent = messages[Math.min(index, messages.length - 1)];
      index++;
      if (progress >= 100) {
        clearInterval(timer);
        setTimeout(() => {
          loader.classList.add('hidden');
          document.body.classList.remove('loading');
          cancelAnimationFrame(raf);
          setTimeout(() => loader.remove(), 650);
        }, 350);
      }
    }, 170);
  }

  // ---------------- STARS / PARTICLES ----------------
  function createStars() {
    const container = $('#stars');
    if (!container || container.dataset.ready) return;
    container.dataset.ready = '1';
    const fragment = document.createDocumentFragment();
    for (let i = 0; i < 190; i++) {
      const star = document.createElement('div');
      const size = Math.random() * 3 + 1;
      star.style.cssText = `width:${size}px;height:${size}px;left:${Math.random() * 100}%;top:${Math.random() * 100}%;opacity:${Math.random() * .8 + .2};animation:twinkle ${Math.random() * 3 + 2}s ease-in-out infinite;`;
      fragment.appendChild(star);
    }
    container.appendChild(fragment);
    const style = document.createElement('style');
    style.textContent = '@keyframes twinkle{0%,100%{opacity:.3;transform:scale(1)}50%{opacity:1;transform:scale(1.5)}} #stars>div{position:absolute;border-radius:50%;background:#fff}';
    document.head.appendChild(style);
  }

  let scene, camera, renderer, particles;
  function initParticles() {
    if (state.reducedMotion) return;
    const canvas = $('#particle-canvas');
    if (!canvas) return;

    const THREE_URL = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    const script = document.createElement('script');
    script.src = THREE_URL;
    script.defer = true;
    script.onload = () => {
      if (typeof window.THREE === 'undefined') return;
      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, .1, 1000);
      camera.position.z = 30;
      renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'low-power' });
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
      const geometry = new THREE.BufferGeometry();
      const count = window.innerWidth < 700 ? 420 : 700;
      const positions = new Float32Array(count * 3);
      const colors = new Float32Array(count * 3);
      for (let i = 0; i < count * 3; i += 3) {
        positions[i] = (Math.random() - .5) * 80;
        positions[i + 1] = (Math.random() - .5) * 80;
        positions[i + 2] = (Math.random() - .5) * 40;
        const r = Math.random();
        if (r < .33) { colors[i] = .75; colors[i + 1] = .52; colors[i + 2] = .98; }
        else if (r < .66) { colors[i] = .13; colors[i + 1] = .83; colors[i + 2] = .93; }
        else { colors[i] = .96; colors[i + 1] = .45; colors[i + 2] = .71; }
      }
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      const material = new THREE.PointsMaterial({ size: .15, vertexColors: true, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: .6 });
      particles = new THREE.Points(geometry, material);
      scene.add(particles);
      function animate() {
        if (!particles) return;
        requestAnimationFrame(animate);
        particles.rotation.x += .0003;
        particles.rotation.y += .0005;
        renderer.render(scene, camera);
      }
      animate();
    };
    document.head.appendChild(script);

    window.addEventListener('resize', () => {
      if (!camera || !renderer) return;
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    }, { passive: true });
  }

  // ---------------- INTERACTION ----------------
  function initCursor() {
    if (window.matchMedia?.('(pointer: coarse)').matches) return;
    const cursor = document.createElement('div');
    cursor.id = 'cursor';
    document.body.appendChild(cursor);
    let x = -100, y = -100, rx = -100, ry = -100;
    const render = () => { rx += (x - rx) * .18; ry += (y - ry) * .18; cursor.style.transform = `translate(${rx}px,${ry}px) translate(-50%,-50%)`; requestAnimationFrame(render); };
    render();
    document.addEventListener('mousemove', e => { x = e.clientX; y = e.clientY; });
    document.addEventListener('mouseleave', () => cursor.classList.remove('visible'));
    document.addEventListener('mouseenter', () => cursor.classList.add('visible'));
    $$('.magnetic, a, button, .tilt-card, .travel-float, .birthday-star-floating').forEach(el => {
      el.addEventListener('mouseenter', () => cursor.classList.add('hover'));
      el.addEventListener('mouseleave', () => cursor.classList.remove('hover'));
    });
    const style = document.createElement('style');
    style.textContent = '#cursor{width:20px;height:20px;border:2px solid var(--neon-cyan);border-radius:50%;position:fixed;left:0;top:0;pointer-events:none;z-index:20000;mix-blend-mode:difference;transition:width .2s,height .2s,background .2s,border-color .2s;opacity:0}#cursor.visible{opacity:1}#cursor.hover{width:42px;height:42px;background:rgba(34,211,238,.18);border-color:transparent}';
    document.head.appendChild(style);
  }

  function initCardInteractions() {
    if (state.reducedMotion) return;
    $$('.tilt-card').forEach(card => {
      card.addEventListener('mousemove', event => {
        const rect = card.getBoundingClientRect();
        const px = (event.clientX - rect.left) / rect.width;
        const py = (event.clientY - rect.top) / rect.height;
        const rotateX = (0.5 - py) * 5;
        const rotateY = (px - 0.5) * 5;
        card.style.setProperty('--mx', `${px * 100}%`);
        card.style.setProperty('--my', `${py * 100}%`);
        card.style.transform = `perspective(900px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-3px)`;
      });
      card.addEventListener('mouseleave', () => { card.style.transform = ''; });
    });

    $$('.magnetic').forEach(button => {
      button.addEventListener('mousemove', event => {
        const rect = button.getBoundingClientRect();
        const x = event.clientX - rect.left - rect.width / 2;
        const y = event.clientY - rect.top - rect.height / 2;
        button.style.transform = `translate(${x * .06}px, ${y * .1}px) translateY(-2px)`;
      });
      button.addEventListener('mouseleave', () => { button.style.transform = ''; });
    });

    $$('.travel-float').forEach(el => {
      el.addEventListener('mouseenter', () => { el.style.opacity = '.85'; el.style.transform += ' scale(1.3)'; });
      el.addEventListener('mouseleave', () => { el.style.opacity = '.22'; });
    });
  }

  // ---------------- NAV / SCROLL ----------------
  function initNavigation() {
    const nav = $('.glass-nav');
    const menuButton = $('#mobile-menu-btn');
    menuButton?.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(open));
      menuButton.innerHTML = `<i class="fas ${open ? 'fa-xmark' : 'fa-bars'}"></i>`;
    });
    $$('#nav-links a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

    const progress = $('#progress-bar');
    const sections = $$('main section[id]');
    const links = $$('#nav-links a');
    const onScroll = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      if (progress) progress.style.width = `${total > 0 ? (window.scrollY / total) * 100 : 0}%`;
      const top = window.scrollY + 160;
      let current = 'home';
      sections.forEach(section => { if (top >= section.offsetTop) current = section.id; });
      links.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${current}`));
      $('#back-to-top')?.classList.toggle('show', window.scrollY > 500);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    $('#back-to-top')?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  function initReveal() {
    const elements = $$('.reveal');
    if (!('IntersectionObserver' in window) || state.reducedMotion) { elements.forEach(el => el.classList.add('visible')); return; }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); } });
    }, { threshold: .12 });
    elements.forEach(el => observer.observe(el));
  }

  function initSkillBars() {
    const bars = $$('.skill-fill');
    if (!('IntersectionObserver' in window)) { bars.forEach(bar => bar.style.width = bar.dataset.width); return; }
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) { entry.target.style.width = entry.target.dataset.width; obs.unobserve(entry.target); } });
    }, { threshold: .3 });
    bars.forEach(bar => obs.observe(bar));
  }

  // ---------------- GITHUB ----------------
  const githubAPI = `https://api.github.com/users/${CONFIG.githubUser}`;
  async function getAllRepos(force = false) {
    const cached = readCache();
    if (!force && cached?.repos?.length) return { data: cached, source: 'cache' };

    const user = await fetchJSON(githubAPI);
    const repos = [];
    for (let page = 1; page <= CONFIG.maxRepoPages; page++) {
      const pageData = await fetchJSON(`${githubAPI}/repos?per_page=${CONFIG.repoPageSize}&page=${page}&sort=updated&direction=desc`);
      repos.push(...pageData);
      if (pageData.length < CONFIG.repoPageSize) break;
    }
    const unique = [...new Map(repos.map(repo => [repo.id, repo])).values()];
    const data = { user, repos: unique, fetchedAt: Date.now() };
    localStorage.setItem(CONFIG.cacheKey, JSON.stringify(data));
    return { data, source: 'network' };
  }

  function readCache() {
    try {
      const data = JSON.parse(localStorage.getItem(CONFIG.cacheKey) || 'null');
      if (!data) return null;
      if (Date.now() - data.fetchedAt > CONFIG.cacheTTL) return null;
      return data;
    } catch { return null; }
  }

  function readStaleCache() {
    try { return JSON.parse(localStorage.getItem(CONFIG.cacheKey) || 'null'); } catch { return null; }
  }

  function repoPagesUrl(repo) {
    if (repo.homepage && /^https?:\/\//i.test(repo.homepage)) return repo.homepage;
    if (repo.has_pages) return repo.name.toLowerCase() === CONFIG.githubUser.toLowerCase() ? `https://${CONFIG.githubUser}.github.io/` : `https://${CONFIG.githubUser}.github.io/${encodeURIComponent(repo.name)}`;
    return null;
  }

  function isLikelyLivePage(repo) {
    return Boolean(repoPagesUrl(repo));
  }

  function normalizeSite(repo) {
    const url = repoPagesUrl(repo);
    if (!url) return null;
    return {
      id: repo.id,
      name: repo.name,
      description: repo.description || 'GitHub Pages project',
      url,
      repoUrl: repo.html_url,
      updatedAt: repo.updated_at,
      stars: repo.stargazers_count,
      topics: repo.topics || []
    };
  }

  function sortRepos(list, sort) {
    const sorted = [...list];
    if (sort === 'stars') sorted.sort((a, b) => b.stargazers_count - a.stargazers_count);
    else if (sort === 'forks') sorted.sort((a, b) => b.forks_count - a.forks_count);
    else if (sort === 'name') sorted.sort((a, b) => a.name.localeCompare(b.name));
    else sorted.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
    return sorted;
  }

  function renderProjectCard(repo) {
    const tags = (repo.topics || []).slice(0, 4).map(t => `<span>${escapeHTML(t)}</span>`).join('');
    return `<article class="project-card">
      <div class="project-topline"><h3>${escapeHTML(repo.name)}</h3><span class="project-star">★ ${formatNumber(repo.stargazers_count)}</span></div>
      <p>${escapeHTML(repo.description || 'No description provided.')}</p>
      <div class="project-tags">${tags || '<span>repository</span>'}</div>
      <div class="project-meta"><span><i class="fas fa-code-branch"></i> ${formatNumber(repo.forks_count)}</span><span><i class="fas fa-clock"></i> ${relativeDate(repo.updated_at)}</span></div>
      <div class="project-links"><a href="${escapeHTML(repo.html_url)}" target="_blank" rel="noopener noreferrer"><i class="fab fa-github"></i> Source</a>${repo.homepage ? `<a href="${escapeHTML(repo.homepage)}" target="_blank" rel="noopener noreferrer"><i class="fas fa-external-link-alt"></i> Demo</a>` : ''}</div>
    </article>`;
  }

  function renderMiniRepo(repo) {
    return `<article class="repo-mini"><h4>${escapeHTML(repo.name)}</h4><p>${escapeHTML(repo.description || 'No description')}</p><footer><span>★ ${formatNumber(repo.stargazers_count)}</span><a href="${escapeHTML(repo.html_url)}" target="_blank" rel="noopener noreferrer">Open ↗</a></footer></article>`;
  }

  function updateProjectViews() {
    const search = ($('#project-search')?.value || '').trim().toLowerCase();
    const sort = $('#project-sort')?.value || 'updated';
    let repos = state.repos.filter(repo => {
      const haystack = `${repo.name} ${repo.description || ''} ${(repo.topics || []).join(' ')}`.toLowerCase();
      return haystack.includes(search);
    });
    repos = sortRepos(repos, sort);
    state.filteredRepos = repos;

    const featured = $('#projects-container');
    const all = $('#all-projects-container');
    if (featured) featured.innerHTML = repos.slice(0, CONFIG.featuredProjects).map(renderProjectCard).join('') || '<div class="glass-card">No matching repositories found.</div>';
    if (all) all.innerHTML = repos.map(renderMiniRepo).join('');
    const button = $('#show-all-projects');
    if (button) button.innerHTML = `<i class="fas fa-layer-group"></i> Show ${repos.length > CONFIG.featuredProjects ? 'all' : 'repository explorer'} (${repos.length})`;
  }

  function renderWebsiteCard(site, { iframe = false } = {}) {
    const src = iframe ? `src="${escapeHTML(site.url)}"` : '';
    const placeholder = iframe ? '' : '<div class="portal-placeholder"><i class="fas fa-satellite-dish"></i><span>Preview sleeps until needed…</span></div>';
    return `<article class="website-card glass-card tilt-card">
      <div class="portal-frame" data-site-url="${escapeHTML(site.url)}">${placeholder}<iframe ${src} title="${escapeHTML(site.name)}" loading="lazy" sandbox="allow-scripts allow-same-origin" referrerpolicy="no-referrer-when-downgrade" ${iframe ? '' : 'data-lazy-frame="1"'}></iframe><div class="portal-overlay"></div></div>
      <div class="website-info"><h3 class="font-tech">${escapeHTML(site.name)}</h3><p>${escapeHTML(site.description)}</p><div class="site-status"><i class="fas fa-circle-check"></i> GitHub Pages detected · ${relativeDate(site.updatedAt)}</div><a href="${escapeHTML(site.url)}" target="_blank" rel="noopener noreferrer" class="website-link">Visit Site <i class="fas fa-external-link-alt"></i></a></div>
    </article>`;
  }

  function setupLazyFrames(root) {
    const frames = $$('iframe[data-lazy-frame="1"]', root);
    if (!frames.length) return;
    const load = frame => {
      if (!frame.dataset.loaded) {
        frame.src = frame.closest('.portal-frame')?.dataset.siteUrl || '';
        frame.dataset.loaded = '1';
        frame.previousElementSibling?.remove();
        frame.removeAttribute('data-lazy-frame');
      }
    };
    if (!('IntersectionObserver' in window)) { frames.slice(0, 3).forEach(load); return; }
    const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { load(entry.target); observer.unobserve(entry.target); } }), { rootMargin: '250px' });
    frames.forEach(frame => observer.observe(frame));
  }

  function updateSiteViews() {
    const query = ($('#site-search')?.value || '').trim().toLowerCase();
    state.filteredSites = state.sites.filter(site => `${site.name} ${site.description} ${site.topics.join(' ')}`.toLowerCase().includes(query));
    const featured = $('#websites-featured');
    const all = $('#all-sites-container');
    if (featured) featured.innerHTML = state.sites.slice(0, CONFIG.featuredSites).map(site => renderWebsiteCard(site)).join('');
    if (all) all.innerHTML = state.filteredSites.map(site => renderWebsiteCard(site)).join('') || '<div class="glass-card">No matching live sites found.</div>';
    setupLazyFrames(document);
    $('#liveCount').textContent = formatNumber(state.sites.length);
    $('#site-sync-label').textContent = `${state.sites.length} page${state.sites.length === 1 ? '' : 's'} found`;
    $('#all-sites-summary').textContent = `${state.sites.length} GitHub Pages candidate${state.sites.length === 1 ? '' : 's'} discovered automatically.`;
    initCardInteractions();
  }

  function renderGitHubData(result) {
    const { data, source } = result;
    const repos = data.repos || [];
    state.repos = repos;
    state.sites = repos.filter(isLikelyLivePage).map(normalizeSite).filter(Boolean).sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    $('#repoCount').textContent = formatNumber(data.user?.public_repos);
    $('#followers').textContent = formatNumber(data.user?.followers);
    $('#starsCount').textContent = formatNumber(repos.reduce((sum, repo) => sum + Number(repo.stargazers_count || 0), 0));
    $('#github-status').textContent = source === 'cache' ? 'Showing recently cached GitHub data.' : 'GitHub data synchronized successfully.';
    $('#github-updated').textContent = `Sync: ${new Date(data.fetchedAt || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    $('#project-sync-label').textContent = `${repos.length} repositories indexed`;
    updateProjectViews();
    updateSiteViews();
  }

  async function loadGitHub(force = false) {
    const previous = readStaleCache();
    try {
      const result = await getAllRepos(force);
      renderGitHubData(result);
    } catch (error) {
      if (previous?.repos?.length) {
        renderGitHubData({ data: previous, source: 'cache' });
        $('#github-status').textContent = 'GitHub is temporarily unreachable; showing cached data.';
        showToast('GitHub sync failed; cached data is being used.', 'error');
      } else {
        $('#github-status').textContent = 'GitHub data could not be loaded right now.';
        $('#project-sync-label').textContent = 'Offline mode';
        $('#site-sync-label').textContent = 'Offline mode';
      }
    }
  }

  // ---------------- COPY / THEME / BIRTHDAY ----------------
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch {
      const area = document.createElement('textarea'); area.value = text; area.style.position = 'fixed'; area.style.opacity = '0'; document.body.appendChild(area); area.select(); const ok = document.execCommand('copy'); area.remove(); return ok;
    }
  }

  function initCopyButtons() {
    $$('.copy-btn').forEach(button => button.addEventListener('click', async () => {
      const target = $(`#${button.dataset.copyTarget}`);
      if (!target) return;
      const ok = await copyText(target.textContent.trim());
      if (ok) { const old = button.textContent; button.textContent = '✓ Copied'; button.classList.add('copied'); showToast('Address copied to clipboard.'); setTimeout(() => { button.textContent = old; button.classList.remove('copied'); }, 1800); }
      else showToast('Copy failed.', 'error');
    }));
    $('#copy-profile')?.addEventListener('click', async () => {
      const ok = await copyText(window.location.href);
      showToast(ok ? 'Profile link copied.' : 'Could not copy profile link.', ok ? 'success' : 'error');
    });
  }

  function initTheme() {
    const button = $('#theme-toggle');
    const saved = localStorage.getItem('mehrdad-theme');
    if (saved === 'light') document.documentElement.dataset.theme = 'light';
    function updateIcon() { button.innerHTML = `<i class="fas ${document.documentElement.dataset.theme === 'light' ? 'fa-sun' : 'fa-moon'}"></i>`; }
    updateIcon();
    button?.addEventListener('click', () => {
      const light = document.documentElement.dataset.theme === 'light';
      document.documentElement.dataset.theme = light ? 'dark' : 'light';
      localStorage.setItem('mehrdad-theme', light ? 'dark' : 'light');
      updateIcon();
      showToast(light ? 'Dark mode enabled.' : 'Light mode enabled.');
    });
  }

  function initBirthday() {
    const star = $('#birthday-star');
    if (!star) return;
    const birthDate = new Date(2001, 9, 13);
    function update() {
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const thisYearBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
      if (today < thisYearBirthday) age--;
      const next = today < thisYearBirthday ? thisYearBirthday : new Date(today.getFullYear() + 1, birthDate.getMonth(), birthDate.getDate());
      const daysLeft = Math.ceil((next - today) / 86400000);
      const text = `Birthday: October 13 · Age ${age} · ${daysLeft} days until next birthday`;
      star.title = text; star.setAttribute('aria-label', text); star.dataset.tooltip = text;
    }
    update();
    setInterval(update, 3600000);
    star.addEventListener('click', () => showToast(star.title));
  }

  // ---------------- MAPS (LAZY) ----------------
  let leafletLoaded = false;
  async function loadLeaflet() {
    if (leafletLoaded || window.L) return;
    await new Promise((resolve, reject) => {
      const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css);
      const script = document.createElement('script'); script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; script.onload = resolve; script.onerror = reject; document.body.appendChild(script);
    });
    leafletLoaded = true;
  }

  async function initMaps() {
    try {
      await loadLeaflet();
      const locations = [
        { id: 'map-school', lat: 29.623503, lng: 52.475145, label: 'Tohidi High School' },
        { id: 'map-uni', lat: 29.625778, lng: 52.493417, label: 'Zand Institute' },
        { id: 'map-service', lat: 29.62875, lng: 51.64139, label: 'Service Location' }
      ];
      locations.forEach(loc => {
        const container = document.getElementById(loc.id);
        if (!container || container.dataset.ready) return;
        container.dataset.ready = '1';
        const map = L.map(container).setView([loc.lat, loc.lng], 15);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
        L.marker([loc.lat, loc.lng]).addTo(map).bindPopup(loc.label).openPopup();
        setTimeout(() => map.invalidateSize(), 250);
      });
    } catch { showToast('Map resources could not be loaded.', 'error'); }
  }

  // ---------------- EXTRAS ----------------
  function initRoadmap() {
    const start = new Date(2025, 7, 23);
    const end = new Date(2027, 4, 23);
    function update() {
      const today = new Date();
      const total = end - start;
      const elapsed = today - start;
      const percent = Math.min(100, Math.max(0, Math.floor((elapsed / total) * 100)));
      $('#road-fill')?.style.setProperty('width', `${percent}%`);
      $('#road-car')?.style.setProperty('left', `${percent}%`);
      if ($('#progress-percent')) $('#progress-percent').textContent = `${percent}%`;
      if ($('#remaining-days')) $('#remaining-days').textContent = formatNumber(Math.max(0, Math.ceil((end - today) / 86400000)));
    }
    update(); setInterval(update, 3600000);
  }

  const haikus = [
    { jp:'古池や\n蛙飛びこむ\n水の音', en:'Old pond —\na frog jumps in,\nsound of water.', author:'Matsuo Bashō' },
    { jp:'蛍の火や\n吹き消す風の\n恋しき', en:'Firefly’s light —\nthe wind that blows it out\nis dear to me.', author:'Kobayashi Issa' },
    { jp:'我死なば\n筆を捨てよと\n蝉の声', en:'When I die,\nthrow away my brush —\nthe cicada’s cry.', author:'Miyamoto Musashi' },
    { jp:'荒海や\n佐渡によこたふ\n天の川', en:'Rough sea —\nstretching towards Sado,\nthe Milky Way.', author:'Matsuo Bashō' }
  ];
  function initHaiku() {
    let index = 0;
    const render = () => { const item = haikus[index]; $('#haiku-jp').innerHTML = escapeHTML(item.jp).replace(/\\n/g, '<br>'); $('#haiku-en').textContent = item.en; $('#haiku-author').textContent = `— ${item.author}`; };
    render();
    if (!state.reducedMotion) setInterval(() => { index = (index + 1) % haikus.length; render(); }, 8000);
  }

  // ---------------- PANELS / COMMAND PALETTE ----------------
  function togglePanel(id, open) {
    const panel = $(id); if (!panel) return; panel.hidden = !open; if (open) panel.scrollIntoView({ behavior: state.reducedMotion ? 'auto' : 'smooth', block: 'start' });
  }
  function initPanels() {
    $('#show-all-projects')?.addEventListener('click', () => { state.allProjectsOpen = !state.allProjectsOpen; togglePanel('#all-projects-panel', state.allProjectsOpen); });
    $('#close-all-projects')?.addEventListener('click', () => { state.allProjectsOpen = false; togglePanel('#all-projects-panel', false); });
    $('#show-all-sites')?.addEventListener('click', () => { state.allSitesOpen = !state.allSitesOpen; togglePanel('#all-sites-panel', state.allSitesOpen); if (state.allSitesOpen) setupLazyFrames($('#all-sites-panel')); });
    $('#close-all-sites')?.addEventListener('click', () => { state.allSitesOpen = false; togglePanel('#all-sites-panel', false); });
    $('#project-search')?.addEventListener('input', updateProjectViews);
    $('#project-sort')?.addEventListener('change', updateProjectViews);
    $('#site-search')?.addEventListener('input', updateSiteViews);
    $('#journey-details')?.addEventListener('toggle', event => { if (event.target.open) initMaps(); });
  }

  function initCommandPalette() {
    const modal = $('#command-palette'); const list = $('#command-list'); const input = $('#palette-search');
    const items = [
      ['Home','#home','fa-house'],['About','#about','fa-user'],['Education','#education','fa-graduation-cap'],['Skills','#skills','fa-microchip'],['Projects','#projects','fa-code'],['Live Websites','#websites','fa-globe'],['More','#extras','fa-layer-group'],['Donate','#donate','fa-gem'],['Contact','#contact','fa-paper-plane']
    ];
    function render(filter = '') { const q = filter.toLowerCase(); list.innerHTML = items.filter(item => item[0].toLowerCase().includes(q)).map(([label,target,icon],i) => `<button class="command-item ${i===0?'active':''}" type="button" data-target="${target}"><span><i class="fas ${icon}"></i> ${label}</span><small>#${target.slice(1)}</small></button>`).join('') || '<div class="command-item">No commands</div>'; $$('.command-item', list).forEach(btn => btn.addEventListener('click', () => { modal.hidden = true; document.querySelector(btn.dataset.target)?.scrollIntoView({ behavior: state.reducedMotion ? 'auto' : 'smooth' }); })); }
    function open() { modal.hidden = false; render(); setTimeout(() => input?.focus(), 0); }
    $('#palette-toggle')?.addEventListener('click', open); $('#close-palette')?.addEventListener('click', () => modal.hidden = true); $$('[data-close-palette]').forEach(el => el.addEventListener('click', () => modal.hidden = true)); input?.addEventListener('input', e => render(e.target.value));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') modal.hidden = true; if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); open(); } });
    render();
  }

  function initYear() { const year = $('#current-year'); if (year) year.textContent = new Date().getFullYear(); }

  async function boot() {
    initMatrixLoader();
    createStars();
    initParticles();
    initCursor();
    initNavigation();
    initReveal();
    initSkillBars();
    initTheme();
    initBirthday();
    initCopyButtons();
    initRoadmap();
    initHaiku();
    initPanels();
    initCommandPalette();
    initCardInteractions();
    initYear();
    updateProjectViews();
    updateSiteViews();
    await loadGitHub(false);
    $('#refresh-github')?.addEventListener('click', async () => { const icon = $('#refresh-github i'); icon?.classList.add('fa-spin'); await loadGitHub(true); icon?.classList.remove('fa-spin'); });
  }

  window.addEventListener('load', boot, { once: true });
})();
