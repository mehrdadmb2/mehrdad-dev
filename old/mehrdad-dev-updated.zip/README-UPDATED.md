# Updated `mehrdad-dev`

This version keeps the site fully static/GitHub Pages compatible and removes the manually maintained project/site lists.

## Files
- `index.html`
- `style.css`
- `script.js`

## Dynamic behavior
- Loads public GitHub profile/repository data automatically.
- Fetches all public repositories through pagination.
- Caches GitHub data locally for 15 minutes and falls back to stale cache when the API is unavailable.
- Automatically discovers repositories with GitHub Pages enabled via repository metadata (`has_pages`).
- Shows only 3 featured live-site previews initially.
- Loads iframe previews lazily as cards approach the viewport.
- The complete live-site collection stays inside a separate expandable panel.
- Custom GitHub Pages URLs are resolved only after the user opens that panel, with bounded concurrency.
- No GitHub token is stored in the frontend.

## Deployment
Commit the three files to the `main` branch of the repository that publishes the portfolio.
